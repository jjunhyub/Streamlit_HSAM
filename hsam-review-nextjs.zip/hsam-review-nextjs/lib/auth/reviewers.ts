// @ts-nocheck

import crypto from 'node:crypto';

function parseReviewerUsers() {
  const raw = process.env.REVIEWER_USERS_JSON?.trim() || '{}';
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    return parsed;
  } catch {
    throw new Error('REVIEWER_USERS_JSON is not valid JSON.');
  }
}

export function getReviewerUsers() {
  return parseReviewerUsers();
}

export function verifyReviewerPassword(reviewerId: string, password: string) {
  const users = parseReviewerUsers();
  const entry = users?.[reviewerId];
  if (!entry) return false;

  const passwordHash = typeof entry === 'string' ? entry : entry.passwordHash;
  if (!passwordHash || typeof passwordHash !== 'string') return false;

  const parts = passwordHash.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;

  const salt = Buffer.from(parts[1], 'base64');
  const expected = Buffer.from(parts[2], 'base64');
  const actual = crypto.scryptSync(password, salt, expected.length);

  if (actual.length !== expected.length) return false;
  return crypto.timingSafeEqual(actual, expected);
}
