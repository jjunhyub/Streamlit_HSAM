// @ts-nocheck
'use client';

import { useMemo, useState } from 'react';
import { getInspectorPills, nodeAssets } from '../lib/review-logic';

function buildAssetUrl(imageId, path) {
  if (!path) return '';
  const params = new URLSearchParams({ imageId: String(imageId), path: String(path) });
  return `/api/assets?${params.toString()}`;
}

function FigureCard({ title, children }) {
  return (
    <div className="figureCard">
      <div className="figureTitle">{title}</div>
      {children}
    </div>
  );
}

function AspectFrame({ width, height, children, dark = true }) {
  const w = Math.max(1, Number(width || 1));
  const h = Math.max(1, Number(height || 1));
  return (
    <div className={`aspectFrame ${dark ? 'isDark' : ''}`} style={{ aspectRatio: `${w} / ${h}` }}>
      {children}
    </div>
  );
}

function DirectImageFigure({ imageId, path, title, fullSize }) {
  if (!path) return null;
  const url = buildAssetUrl(imageId, path);
  return (
    <FigureCard title={title}>
      <AspectFrame width={fullSize?.[0]} height={fullSize?.[1]}>
        <img className="frameImage" src={url} alt={title} loading="lazy" />
      </AspectFrame>
    </FigureCard>
  );
}

function OverlayFigure({ imageId, basePath, maskPath, title, fullSize }) {
  if (!basePath || !maskPath) return null;
  const baseUrl = buildAssetUrl(imageId, basePath);
  const maskUrl = buildAssetUrl(imageId, maskPath);

  return (
    <FigureCard title={title}>
      <AspectFrame width={fullSize?.[0]} height={fullSize?.[1]}>
        <img className="frameImage" src={baseUrl} alt={title} loading="lazy" />
        <div
          className="maskOverlayLayer"
          style={{
            WebkitMaskImage: `url(${maskUrl})`,
            maskImage: `url(${maskUrl})`,
          }}
        />
      </AspectFrame>
    </FigureCard>
  );
}

function RestoredCropFigure({ imageId, cropPath, bbox, fullSize, title }) {
  if (!cropPath || !bbox || !fullSize) return null;
  const [x1, y1, x2, y2] = bbox;
  const [fullW, fullH] = fullSize;
  const cropUrl = buildAssetUrl(imageId, cropPath);

  return (
    <FigureCard title={title}>
      <AspectFrame width={fullW} height={fullH}>
        <img
          className="restoredCropImage"
          src={cropUrl}
          alt={title}
          loading="lazy"
          style={{
            left: `${(x1 / fullW) * 100}%`,
            top: `${(y1 / fullH) * 100}%`,
            width: `${((x2 - x1) / fullW) * 100}%`,
            height: `${((y2 - y1) / fullH) * 100}%`,
          }}
        />
      </AspectFrame>
    </FigureCard>
  );
}

export default function VisualsPanel({ record, nodeId, translationMap }) {
  const [showInstances, setShowInstances] = useState(false);
  const assets = useMemo(() => nodeAssets(record, nodeId), [record, nodeId]);
  const leaf = String(nodeId || '').split('__').at(-1) || nodeId;
  const pills = useMemo(() => getInspectorPills(record, nodeId, translationMap), [record, nodeId, translationMap]);

  const reviewFigures = [
    assets.root_original ? (
      <DirectImageFigure
        key="root-original"
        imageId={record.image_id}
        path={assets.root_original}
        title="원본 이미지"
        fullSize={assets.full_size}
      />
    ) : null,
    assets.root_original && assets.mask ? (
      <OverlayFigure
        key="overlay"
        imageId={record.image_id}
        basePath={assets.root_original}
        maskPath={assets.mask}
        title={`<${leaf}> 오버레이`}
        fullSize={assets.full_size}
      />
    ) : null,
    assets.mask_original ? (
      <RestoredCropFigure
        key="mask-original"
        imageId={record.image_id}
        cropPath={assets.mask_original}
        bbox={assets.bbox}
        fullSize={assets.full_size}
        title={`<${leaf}> 원본`}
      />
    ) : null,
    assets.mask ? (
      <DirectImageFigure
        key="mask"
        imageId={record.image_id}
        path={assets.mask}
        title={`<${leaf}> 마스크`}
        fullSize={assets.full_size}
      />
    ) : null,
    assets.instances_colored ? (
      <DirectImageFigure
        key="instances-colored"
        imageId={record.image_id}
        path={assets.instances_colored}
        title={`<${leaf}> 인스턴스`}
        fullSize={assets.full_size}
      />
    ) : null,
  ].filter(Boolean);

  return (
    <section className="sectionCard">
      <div className="sectionHeaderWithMeta">
        <div>
          <h2 className="sectionTitle">Visuals</h2>
          <div className="statusPillsRow">
            {pills.map((pill) => (
              <span className="statusPill" key={pill}>{pill}</span>
            ))}
          </div>
        </div>
      </div>

      {reviewFigures.length ? (
        <div className="visualsGrid">{reviewFigures}</div>
      ) : (
        <div className="emptyBox">노드 검토용 이미지를 찾지 못했습니다.</div>
      )}

      <div className="toggleRow">
        <label className="toggleLabel">
          <input type="checkbox" checked={showInstances} onChange={(event) => setShowInstances(event.target.checked)} />
          인스턴스 보기
        </label>
      </div>

      {showInstances ? (
        assets.instances?.length ? (
          <div className="visualsGrid">
            {assets.instances.map((instancePath, index) => (
              <DirectImageFigure
                key={instancePath}
                imageId={record.image_id}
                path={instancePath}
                title={`${leaf} #${index + 1}`}
                fullSize={assets.full_size}
              />
            ))}
          </div>
        ) : (
          <div className="emptyBox">인스턴스 마스크가 없습니다.</div>
        )
      ) : null}
    </section>
  );
}
